get.c <-
function (i, nr) 
{
    i%/%nr + 1
}
