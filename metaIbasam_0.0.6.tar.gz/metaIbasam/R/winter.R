winter <-
function () 
{
    .C("winter", PACKAGE = "metaIbasam")
    invisible(NULL)
}
