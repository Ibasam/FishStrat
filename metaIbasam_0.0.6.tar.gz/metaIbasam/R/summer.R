summer <-
function () 
{
    .C("summer", PACKAGE = "metaIbasam")
    invisible(NULL)
}
