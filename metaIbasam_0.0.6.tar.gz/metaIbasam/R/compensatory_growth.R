compensatory_growth <-
function () 
{
    .C("compensatory_growth", PACKAGE = "metaIbasam")
    invisible(NULL)
}
